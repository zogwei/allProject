function tenantList(){
	$.post(
			{
				url:"system/tenantList"
			}
		);
}